<?php
	echo("<link rel='icon' href='static/img/tickit_favicon.png'>");	//FAVICON
?>
